---
name: remo-library
description: リモラボ公式コンテンツ（リモライブラリー）の記事を作成するSkill。カテゴリを選び、入力データを渡すと「公式さん」ペルソナで記事を生成・添削・修正できる。
---

# リモライブラリー記事作成 Skill

リモラボ公式コンテンツの記事を、対話ベースで生成・添削・修正するための Skill です。

## 起動方法

「リモライブラリーで記事を作って」「成長シェアの記事を書きたい」など、記事作成に関する依頼で起動します。

## 起動時の案内（必ず表示すること）

カテゴリが明示されていない場合、以下のメニューをユーザーに提示する:

```
リモライブラリー記事作成へようこそ！

どのカテゴリの記事を作りますか？

1️⃣ 最新ニュース … トピックを伝えてください
2️⃣ 月次AIツール情報 … 対象月を伝えてください
3️⃣ 成果報告 … CSV or テキストデータを貼り付けてください
4️⃣ 成長シェア … CSV or テキストデータを貼り付けてください
5️⃣ ツール紹介 … ツール名と概要を伝えてください
6️⃣ クライアントワーク報告会 … 文字起こしデータを貼り付けてください
7️⃣ リモラボの裏側 … インタビューデータを貼り付けてください

📋 過去記事を見る … archive/index.md の一覧を表示
🔍 修正記録を棚卸し … correction-log.md を分析してルール提案
```

番号またはカテゴリ名で選択を受け付ける。
「3」「成果報告」「成果報告の記事を書きたい」のいずれでもOK。

カテゴリが決まったら、そのカテゴリに必要な入力データを案内する:
- 何を用意すればいいか
- どんな形式（テキスト / CSV / ファイル添付）で渡せばいいか
- 入力例がある場合は `samples/input-examples/` を案内する

## カテゴリ一覧

| # | カテゴリ | 説明 | 入力方法 | 詳細 |
|---|---------|------|---------|------|
| 1 | 最新ニュース | フリーランス・AI・社会情勢などのニュース記事 | トピックをテキストで | [categories/news-article.md](categories/news-article.md) |
| 2 | 月次AIツール情報 | 主要AIツールの月次アップデートまとめ | 対象月を指定 | [categories/monthly-ai-tools.md](categories/monthly-ai-tools.md) |
| 3 | 成果報告 | メンバーの成果事例を紹介する記事 | CSV or テキスト貼り付け | [categories/achievement.md](categories/achievement.md) |
| 4 | 成長シェア | 悩みや壁をどう乗り越えたかの記事 | CSV or テキスト貼り付け | [categories/growth-share.md](categories/growth-share.md) |
| 5 | ツール紹介 | 便利ツールの使い方・活用法の記事 | ツール名+概要をテキストで | [categories/tool-intro.md](categories/tool-intro.md) |
| 6 | クライアントワーク報告会 | 報告会の文字起こしから記事化 | VTT/テキスト貼り付け | [categories/client-work-report.md](categories/client-work-report.md) |
| 7 | リモラボの裏側 | 運営スタッフへのインタビュー記事 | CSV or テキスト貼り付け | [categories/behind-scenes.md](categories/behind-scenes.md) |

## 必ず読むファイル

記事を生成する前に、以下を**すべて**読み込んでください。

### 実行層（ルール・テンプレート）
1. **[rules/persona.md](rules/persona.md)** -- 「公式さん」ペルソナ定義（最重要）
2. **[rules/writing-rules.md](rules/writing-rules.md)** -- ライティング・装飾・表記ルール
3. **[rules/editor-checklist.md](rules/editor-checklist.md)** -- 添削チェックリスト（Phase 0〜8）
4. **該当カテゴリの手順ファイル**（上記一覧から選択）

### 根拠層（なぜそのルールか）
5. **[rules/rules-rationale.md](rules/rules-rationale.md)** -- 各ルールの背景・目的・失敗体験

### 知識層（専門知識・判断ガイド）
6. **[references/knowledge-base.md](references/knowledge-base.md)** -- フレームワーク・心理的アプローチ・判断ガイド
7. **[references/remocity-decoration.md](references/remocity-decoration.md)** -- リモシティ装飾仕様（太字・引用・レイアウト）

### 記録層（蓄積データ）
8. **[data/learned-rules.md](data/learned-rules.md)** -- 学習済みルール（生成時に反映）
9. **[data/correction-log.md](data/correction-log.md)** -- 修正記録（棚卸し時に参照）
10. **[archive/](archive/)** -- 公開済み過去記事（同カテゴリがあればトーンを参考にする）

## 作業手順

### Step 1: カテゴリ確認

ユーザーにカテゴリを確認する。明示されていれば確認不要。

### Step 2: 入力データの取得

カテゴリに応じた入力を受け取る。入力形式はカテゴリ別ファイルに記載。

**入力データの受け取り方（3パターン）:**

1. **チャットに直接貼り付け** — テキストやCSVデータをそのままチャットに貼ってもらう
2. **ファイルを添付** — Cursor のチャット欄にファイルをドラッグ＆ドロップ、または `@ファイル名` で参照してもらう
3. **ファイルパスを指定** — 「`C:\Users\...\data.csv` を読んで」と言ってもらう

CSVデータを受け取った場合は、内容をMarkdownテーブル形式に整形してからユーザーに確認する。
入力データの実例が必要な場合は `samples/input-examples/` を案内する。

### Step 3: 重複チェック

成果報告・リモラボの裏側 → [data/featured-persons.json](data/featured-persons.json) を確認
成長シェア → [data/used-themes.json](data/used-themes.json) を確認

該当者/テーマが既出の場合は警告する（生成はブロックしない）。

### Step 4: 記事生成

1. ルールファイル（persona.md, writing-rules.md）を前提知識として適用
2. カテゴリ別ファイルの指示に従って記事を生成
3. 学習ルール [data/learned-rules.md](data/learned-rules.md) が存在すれば、その内容も反映

### Step 5: 添削

1. [rules/editor-checklist.md](rules/editor-checklist.md) に従って自己添削
2. 6軸で採点し、90点以上になるまで修正
3. 添削結果と修正済み記事をユーザーに提示

### Step 6: ユーザー確認・修正

ユーザーから修正指示があれば反映。「公式さん」の口調を維持したまま修正する。

### Step 7: 保存 & プレビュー

完成記事を以下に保存:
- `output/YYYY-MM-DD-カテゴリ-タイトル.md`

重複管理データを更新:
- 成果報告 / リモラボの裏側 → `data/featured-persons.json` に追記
- 成長シェア → `data/used-themes.json` に追記

保存後、ユーザーに以下を案内する:
```
記事を保存しました！

📱 スマホ風プレビューで確認しますか？
→ preview.html をブラウザで開いて、保存したファイルをドラッグ＆ドロップしてください。

または、このチャットで「プレビューを開いて」と言っていただければ、ブラウザで開きます。
```

ユーザーが「プレビューを開いて」と言った場合、シェルコマンドで `preview.html` をブラウザで起動する。

### Step 7.5: アーカイブ（公開後）

ユーザーが「リモシティに投稿した」「公開した」と伝えたら:

1. 完成記事を `archive/YYYY-MM-DD_カテゴリ_タイトルまたは名前.md` にコピー
2. `archive/index.md` の記事一覧テーブルに1行追記
3. ユーザーに「アーカイブに保存しました」と報告

**アーカイブの活用**: 次回以降の記事生成時、同じカテゴリの過去記事が `archive/` にあれば読み込み、トーン・品質・構成を揃える参考にする。

### Step 8: 修正記録（必須）

ユーザーが記事を修正した場合、`data/correction-log.md` に以下を記録する:
- 修正箇所
- 修正前 → 修正後
- **なぜ直したか**（最重要）
- 汎用化できるか

## 改善ループ（5層目）

```
実行（記事を生成する）
  ↓
修正（ユーザーが手直しする）
  ↓
記録（correction-log.md に「なぜ直したか」を残す）
  ↓
棚卸し（パターンを見つける）← 5〜10件溜まったらトリガー
  ↓
反映（ルール・知識を更新）
  ↓
実行（精度が上がった状態で再開）
```

### 棚卸しのトリガーと手順

**トリガー**: `correction-log.md` の未処理記録が5〜10件溜まったとき

**手順**:
1. `correction-log.md` の未処理記録を読む
2. 繰り返し出現するパターンを探す
3. パターンが見つかったら:
   - **汎用ルール** → `data/learned-rules.md` に追記（根拠付き）
   - **判断ガイド** → `references/knowledge-base.md` に追記
   - **既存ルールの強化** → `rules/` 内の該当ファイルを更新し、`rules/rules-rationale.md` にも根拠を追記
4. `correction-log.md` の棚卸しメモ欄に結果を記録
5. ユーザーに「こういうルールを追加しました」と報告

### 注意

- ルールを追加するとき、必ず根拠も一緒に書く
- learned-rules.md は最大30件。超えたら優先度の低いものを統合
- 矛盾するルールが出たら根拠を比較して1つに統合する

## 出力フォルダ

```
output/           ← 作業中の記事（ローカルのみ）
├── 2026-03-20-news-フリーランスの最新動向.md
└── ...

archive/          ← 公開済みの記事（Git で共有・蓄積）
├── index.md      ← 記事一覧
├── 2026-03-20_behind-scenes_なおさん.md
└── ...
```
